const sliderItems = document.querySelectorAll(".cover")
const currentVideo = document.getElementById("large-vid")


sliderItems.forEach((item)=> {
    item.addEventListener("click",(e)=> {
        var currentFrame = e.currentTarget.nextSibling.nextSibling

        console.log(currentFrame.src)
        currentVideo.src = currentFrame.src
    })
})

